import  React       ,{ 
        Component   ,}  from 'react'
import  Search          from '@material-ui/icons/Search'
import  AddRounded      from '@material-ui/icons/AddRounded'
import  SearchTag       from './SearchTag'
import  axios           from 'axios'
import  {connect}       from 'react-redux'
import  {withAlert}     from 'react-alert'

import  Filter  from "./../tweets/Filter"  

import  "./SearchBar.scss"

class SearchBar extends Component {
    state = {
      tags      : {},
      tweets    : {},
      people    : {},
      token     : this.props.token,
      filters   : []
    }
   
    onChangeUpdate = (n,v)    => {
        this.state.filters.map(f =>{
            f.onChange(n,v)
        })
    }

    onAdd       = (e)   =>  {
        const   tags    = this.state.tags
        tags[Math.random().toString(36).substring(7)]= {
            tag         : "BTC"     ,
            color       : "#1ABC9C" ,
            n_tweets    : 5         ,

            lng         : 150.644   ,
            lat         : -34.397   ,
            radius      : 0         ,
            language    : "ANY"     ,
            type_       : "ALL"     ,
            retweets    : 0         ,
            favorites   : 0         ,
        }
        this.setState({
            tags:tags
        })
    }
    onDelete    = (id_)             => {
        const   tags    = this.state.tags
        this.setState({
            tags:Object.keys(tags).reduce((reduced,key)=>{
                if (key != id_ )reduced[key] = tags[key];
                return reduced
            },{})
        })
    }
    updateTag   = (id_,name,value)  => {
        this.state.tags[id_][name] = value
    }
    onSearch    = ()                => {
        if (Object.keys(this.state.tags).length == 0 )return;
        const   config  = {
            headers: {
                'Content-Type'  : 'application/json'            ,
                'Authorization' : `Token ${this.props.token}`   ,
              },
        }
        const   body            = JSON.stringify(
            Object.keys(this.state.tags).map(k => ({"id_":k, ...this.state.tags[k]}))
            )
        this.props.searching()
        axios.post  ("/api/v1/search",body,config)
        .then  (
                res => {
                    this.props.searched(res)
                })
        .catch (
                err => {
                    this.props.alert.error("Something went wrong")
                    this.props.search_error()
                });

    }

    render() {
        const   tags    = this.state.tags
        return (
            <div className="search-container">
                <ul className="nav tags-ul">
                    {Object.keys(tags).map((id_) => {
                        return <li key={id_}>
                            <SearchTag  tag         = {tags[id_].tag}
                                        id_         = {id_}
                                        color       = {tags[id_].color}
                                        n_tweets    = {tags[id_].n_tweets}
                                        onDelete    = {this.onDelete}   
                                        updateTag   = {this.updateTag}
                                        filters     = {this.state.filters}
                                        >
                            </SearchTag >
                        </li>
                    })}
                    <li>
                        <button className="btn btn-light" onClick={this.onAdd}>
                            <AddRounded></AddRounded>
                        </button>
                    </li>
                </ul>
                <ul className="nav search-ul">
                    <li>
                        <div className="dropdown">
                            <button className="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Filter
                            </button>
                            <div className="dropdown-menu dropdown-menu-right filter-drop" aria-labelledby="dropdownMenuButton">
                                <form>
                                    <Filter onChangeUpdate = {this.onChangeUpdate} id_="main"/>
                                </form>
                            </div>
                        </div>
                    </li>
                    <li>
                        <button className="btn btn-dark" onClick={this.onSearch}>
                            <Search></Search>
                        </button>
                    </li>
                </ul>
            </div>
        )
    }
}

const mapStateToProps       = state     => ({ token: state.token })
const mapDispatchToProps    = dispatch  => ({
    searched    : (res) => dispatch({
        type    : "SEARCHED"    ,
        payload : res.data      ,
    }),
    searching   : ()    => dispatch({
        type    : "SEARCHING"    ,
    }),
    search_error    : ()    => dispatch({
        type        : "SEARCHERROR"    ,
    })
})
export default connect(mapStateToProps, mapDispatchToProps)(withAlert()(SearchBar))